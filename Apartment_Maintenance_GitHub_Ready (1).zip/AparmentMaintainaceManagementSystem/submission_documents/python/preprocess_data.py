from pathlib import Path
import pandas as pd
src=Path('output'); clean=src/'cleaned'; clean.mkdir(parents=True,exist_ok=True)
for file in src.glob('*.csv'):
    df=pd.read_csv(file)
    df.columns=[str(c).strip().lower().replace(' ','_') for c in df.columns]
    df=df.drop_duplicates()
    for col in df.select_dtypes(include=['object']).columns:
        df[col]=df[col].astype('string').str.strip()
    df.to_csv(clean/file.name,index=False)
    print(f'{file.name}: {len(df)} cleaned rows')
