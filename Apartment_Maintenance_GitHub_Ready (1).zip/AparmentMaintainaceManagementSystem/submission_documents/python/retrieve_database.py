import os
from pathlib import Path
import pandas as pd
import psycopg2
from dotenv import load_dotenv

load_dotenv()
out = Path('output'); out.mkdir(exist_ok=True)
conn = psycopg2.connect(host=os.getenv('DB_HOST','localhost'), port=os.getenv('DB_PORT','5432'), dbname=os.getenv('DB_NAME','apartment_db'), user=os.getenv('DB_USER','postgres'), password=os.environ['DB_PASSWORD'])
try:
    with conn.cursor() as cur:
        cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE' ORDER BY table_name")
        tables = [r[0] for r in cur.fetchall()]
    for table in tables:
        safe = table.replace('"','""')
        df = pd.read_sql_query(f'SELECT * FROM public."{safe}"', conn)
        df.to_csv(out / f'{table}.csv', index=False)
        print(f'{table}: {len(df)} rows exported')
finally:
    conn.close()
