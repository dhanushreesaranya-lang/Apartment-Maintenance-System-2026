# SQL Scripts and Normalization

Run `01_inspect_existing_schema.sql` first. It is read-only and captures actual tables, columns and keys. Do not recreate a working schema blindly.

- **1NF:** Store atomic values; do not keep comma-separated complaint/payment lists in one field.
- **2NF:** Every non-key attribute must depend on the whole primary key (especially if composite keys exist).
- **3NF:** Non-key attributes should depend only on the key. Keep resident, bill and payment facts in their appropriate relations rather than duplicating them.
- Use primary and foreign keys for identity and relationships; use suitable types such as NUMERIC for money and DATE/TIMESTAMP for dates.
- Add NOT NULL, UNIQUE and CHECK constraints only when they match actual business rules.

For final submission, paste the inspection query output and update the ER diagram/relational model to match the actual schema exactly.
